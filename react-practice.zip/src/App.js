import React from 'react'
import LayoutContainer from './components/LayoutContainer';

export default function App() {
  return (
    <div>
      <LayoutContainer />
    </div>
  )
}
