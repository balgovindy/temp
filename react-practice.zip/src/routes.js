import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Route } from 'react-router-dom';

const Home = lazy(() => import('./components/Home'));

const AppRouter = () => {
  return (
    <Router>
      <Suspense fallback={<div className="lazy-loading">Loading...</div>}>
        <Route path='/' component={Home} />
      </Suspense>
    </Router>
  );
};

export default AppRouter;
