import React from 'react'
import HorizontalLine from './../HorizontalLine';
import { Space, Avatar, Button, Input } from 'antd';

import {
    CheckCircleOutlined,
    FilterFilled,
    SortAscendingOutlined,
    ThunderboltOutlined,
    AppstoreAddOutlined,
    BlockOutlined,
    EllipsisOutlined
} from '@ant-design/icons';


const rightPart = () => (
    <ul className="list-inline">
        <li className="list-inline-item ml-ul-item mt-0 mr-4">
            <Space>
                <CheckCircleOutlined className="ml-header-icon"/>
                <span>All tasks</span>
            </Space>

        </li>
        <li className="list-inline-item ml-ul-item mt-0 mr-4">
            <Space>
                <FilterFilled className="ml-header-icon" />
                <span>Filter</span>
            </Space>
        </li>
        <li className="list-inline-item ml-ul-item mt-0 mr-4">
            <Space>
                <SortAscendingOutlined className="ml-header-icon"/>
                <span>Sort</span>
            </Space>
        </li>
        <li className="list-inline-item ml-ul-item mt-0  mr-4">
            <Space>
                <ThunderboltOutlined className="ml-header-icon"/>
                <span>Rules</span>
            </Space>
        </li>
        <li className="list-inline-item ml-ul-item mt-0  mr-4">
            <Space>
                <AppstoreAddOutlined className="ml-header-icon"/>
                <span>Apps</span>
            </Space>
        </li>
        <li className="list-inline-item ml-ul-item mt-0  mr-4">
            <Space>
                <BlockOutlined className="ml-header-icon"/>
                <span>Fields</span>
            </Space>
        </li>
        <li className="list-inline-item ml-ul-item mt-0">
            <Space>
                <EllipsisOutlined className="ml-header-icon"/>
            </Space>
        </li>
    </ul>
);
const Tabcontent = () => {
    return (
        <div style={{ marginTop: -44 }}>
            <HorizontalLine />
            <div className="d-flex justify-content-between border-bottom" style={{padding:'0 12px'}}>
                <span>Created today</span>
                {rightPart()}
            </div>
        </div>
    )
}

export default Tabcontent
