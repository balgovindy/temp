import React from 'react'
import {
    MenuFoldOutlined,
    BarChartOutlined,
    CloudOutlined,
    HomeOutlined,
    BellOutlined,
    CheckCircleOutlined,
    StarOutlined,
    PlusOutlined,
    ClockCircleOutlined,
    UserOutlined,
    EllipsisOutlined
} from '@ant-design/icons';
import { Layout, Menu, Avatar } from 'antd';
import './style.css'
const { Sider } = Layout;
import HorizontalLine from './../HorizontalLine'

const rawData = [
    {
        component: <HomeOutlined className="ml-icon" />,
        text: 'Home'
    },
    {
        component: <CheckCircleOutlined className="ml-icon" />,
        text: 'My Tasks'
    },
    {
        component: <BellOutlined className="ml-icon" />,
        text: 'Inbox'
    },
    {
        component: <BarChartOutlined className="ml-icon" />,
        text: 'Portfolios'
    },
    {
        component: <CloudOutlined className="ml-icon" />,
        text: 'Goals'
    }
]
const menuItem = () => (
    rawData.map((data, index) => (
        <Menu.Item key={index} icon={data.component}>
            <span className="ml-item-text ml-color-type1">{data.text}</span>
        </Menu.Item>
    ))
)

const Sidebar = () => {
    return (
        <Sider >
            <div className="d-flex justify-content-between m-4">
                <h3 style={{ color: '#fff' }}>asana</h3>
                <MenuFoldOutlined className="ml-icon ml-color-type1" style={{ lineHeight: '1.75rem' }} />
            </div>
            <Menu theme="dark" mode="inline" >
                {menuItem()}
            </Menu>
            <HorizontalLine />
            <div className="ml-4">
                <p className="ml-font-type1 mb-2 text-light">Favorites</p>
                <p className="ml-font-type2 mb-1" style={{ color: 'rgba(255, 255, 255, 0.5)' }}>Favorite projects by clicking the {<StarOutlined style={{ verticalAlign: 'middle' }} />}</p>
                <a className="ml-font-type2 d-inline-block text-light">show more</a>
            </div>
            <HorizontalLine />
            <div className="ml-4">
                <p className="ml-font-type1 mb-2 text-light">Reports</p>
            </div>
            <HorizontalLine />
            <div className="ml-4 mr-4">
                <div className="d-flex justify-content-between">
                    <p className="ml-item-text ml-color-type1">Engineering</p>
                    <PlusOutlined className="ml-icon ml-color-type1" />
                </div>
                <div className="ml-report bg-secondary p-1">
                    <p className="ml-item-text ml-color-type1 ml-font-type2 m-0">Engineering is currently in trial.</p>
                    <a className="text-info">Learn more</a>
                    <p className="text-light m-0">{<ClockCircleOutlined className="ml-icon ml-item-text" />}&nbsp;30 days remaining</p>
                </div>
            </div>
            <div className="m-4">
                <Avatar size="small" icon={<UserOutlined />} className="" />
                <Avatar size="small" className="m-1" />
                <Avatar size="small" className="" />
                <a className="text-light ml-font-type2"> &nbsp;&nbsp;+ Invite People</a>
            </div>
            <div className="pl-4 pr-4 d-flex justify-content-between bg-secondary">
                <p className="ml-item-text ml-color-type1 m-0">test</p>
                <EllipsisOutlined className="ml-icon ml-color-type1 m-0"/>
                
            </div>
            <HorizontalLine />
            <div className="ml-sider-footer"></div>
        </Sider>
    )
}

export default Sidebar;
