import React from 'react';
import { Layout, Space, Tabs, Avatar, Button, Input } from 'antd';
import './style.css'

import {
    DownOutlined,
    InfoCircleOutlined,
    StarOutlined,
    ShareAltOutlined,
    SearchOutlined,
    PlusCircleFilled,
    QuestionCircleOutlined
} from '@ant-design/icons';

const { Header } = Layout;
const { TabPane } = Tabs;

const leftSide = () => (
    <div className="d-flex">
        <div className="d-inline-block bg-primary ml-logo mt-2 mr-2">
        </div>
        <div>
            <Space>
                <span><span className="font-weight-bold">test</span> <DownOutlined className="ml-header-icon" /></span>
                <InfoCircleOutlined className="ml-header-icon pl-1" />
                <StarOutlined className="ml-header-icon pl-1 pr-2" />
                <span>o Set Status</span>
            </Space>
            <Tabs defaultActiveKey="1" onChange={() => { }}>
                <TabPane tab="List" key="1" />
                <TabPane tab="Board" key="2" />
                <TabPane tab="Timeline" key="3" />
                <TabPane tab="Calender" key="4" />
                <TabPane tab="Progress" key="5" />
                <TabPane tab="Forms" key="6" />
                <TabPane tab="More..." key="7" />
            </Tabs>
        </div>
    </div>
);

const rightSide = () => (
    <ul className="list-inline">
        <li className="list-inline-item ml-ul-item">
            <Space>
                <Avatar size="small">BY</Avatar>
                <Button className="rounded">
                    <ShareAltOutlined className="ml-header-icon" />
                    Share
            </Button>
            </Space>

        </li>
        <li className="list-inline-item ml-ul-item">
            <Space>
                <Input placeholder="Search" className="rounded" prefix={<SearchOutlined />} style={{ width: 100 }} />
                <PlusCircleFilled className="ml-header-icon ml-font-type-1" />
                <QuestionCircleOutlined className="ml-header-icon ml-font-type-1" />
            </Space>
        </li>
        <li className="list-inline-item">
            <Space>
                <div className="bg-light p-1 rounded d-inline-block">
                    <p className="m-0">Trial:30 days left</p>
                    <p className="text-primary mb-0">Add billing info</p>
                </div>
                <Avatar size="small">BY</Avatar>
            </Space>

        </li>
    </ul>
);

const HeaderComp = () => {
    return (
        <Header className="bg-white">
            <div className="d-flex justify-content-between">
                {leftSide()}
                {rightSide()}
            </div>
        </Header>
    )
}

export default HeaderComp
