import React from 'react'
import { Layout } from 'antd';
import Sidebar from './../Sidebar';
import HeaderComp from './../HeaderComp';
import Tabcontent from './../Tabcontent'

const LayoutContainer = () => {
    return (
        <Layout>
            <Sidebar />
            <Layout className="bg-white">
                <HeaderComp />
                <Tabcontent />
            </Layout>
        </Layout>
    )
}

export default LayoutContainer;
