import React from 'react'
import './style.css'
const HorizontalLine = (props) => <div className="ml-hr-line" {...props}></div>

export default HorizontalLine
